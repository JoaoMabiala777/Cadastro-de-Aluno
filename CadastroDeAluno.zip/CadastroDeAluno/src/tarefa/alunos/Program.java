package tarefa.alunos;

import java.util.Scanner;

import tarefa.alunos.menus.AtualizarAluno;
import tarefa.alunos.menus.ConsultarAluno;
import tarefa.alunos.menus.InserirAluno;
import tarefa.alunos.menus.ItemDeMenu;
import tarefa.alunos.menus.ListarAlunosAprovados;
import tarefa.alunos.menus.ListarAlunos;
import tarefa.alunos.menus.ListarAlunosPorMedia;
import tarefa.alunos.menus.ListarAlunosPorNome;
import tarefa.alunos.menus.ListarAlunosReprovados;
import tarefa.alunos.menus.RemoverAluno;
import tarefa.alunos.menus.Sair;

public class Program {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);

		ItemDeMenu[] principal = new ItemDeMenu[] { 
				new InserirAluno(),
				new ListarAlunosPorNome(),
				new ConsultarAluno(),
				new AtualizarAluno(),
				new RemoverAluno(),
				new ListarAlunosAprovados(),
				new ListarAlunosReprovados(),
				new ListarAlunosPorMedia(),
				new Sair() 
		};

		boolean sair = false;
		do {
			for (int i = 0; i < principal.length; i++) {
				System.out.println(i + " - " + principal[i].getDescricao());
			}
			System.out.print("\n\nQual a opcao desejada: ");
			int opcao = Integer.parseInt(console.nextLine());
			System.out.println("\n");
			sair = principal[opcao].executar();
		} while (!sair);
	}

}
