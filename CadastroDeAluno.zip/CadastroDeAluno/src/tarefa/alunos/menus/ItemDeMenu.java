package tarefa.alunos.menus;

import tarefa.alunos.dao.Dao;
import tarefa.alunos.dao.DaoArrayList;
import tarefa.alunos.io.Leitor;

public abstract class ItemDeMenu {
	
	protected Leitor leitor;
	protected Dao dao;
	
	public ItemDeMenu() {
		leitor = new Leitor();
		dao = new DaoArrayList();
	}
	
	public abstract String getDescricao();

	public abstract boolean executar();

}
