package tarefa.alunos.menus;

import tarefa.alunos.modelos.Aluno;

public class ListarAlunosPorNome extends ListarAlunos {

	@Override
	public String getDescricao() {
		return "Listar alunos (ordem alfabetica)";
	}

	@Override
	public boolean deveImprimir(Aluno aluno) {
		return true;
	}

}
